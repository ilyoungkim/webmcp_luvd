# 연애의 자격 AI 비서 (WebMCP)
Version: 0.1.1-alpha.003

현재 이 확장 프로그램은 **알파 테스트 단계**입니다. WebMCP는 Google Chrome/과 같은 브라우저 환경에서 실험적 기능으로 제공되는 **베타 상태**의 기술로 동작할 수 있으며, 브라우저/플랫폼/버전별 지원 범위가 달라질 수 있습니다.

### 빌드 버전 규칙
- 메이저/마이너/패치: `0.1.1`
- 알파 식별자: `alpha`
- 빌드 번호: `001`, `002`, `003` ...
- 매 빌드마다 빌드 번호는 +1 증가
- 예: `0.1.1-alpha.001` → `0.1.1-alpha.002` → `0.1.1-alpha.003`

> Google의 공식 입장상 WebMCP / Prompt API / on-device model 계열 기능은 실험적 기능이며, 모든 환경에서 동일하게 지원되는 것은 아닙니다. 이 확장은 그런 제한을 반영해 **내장 AI 미지원 시 키워드 기반으로 WebMCP 도구를 직접 호출**하는 방식으로 동작합니다.

## 연애의 자격 AI 비서

WebMCP 기반으로 연애의 자격 서비스의 주요 정보를 확인하고, Chrome 내장 AI(구글 제미나이 나노)를 활용해 상담 및 진단 관련 질문을 보다 편리하게 처리할 수 있습니다.

### 현재 상태
- 상태: 알파 테스트
- WebMCP: 베타/실험적 기능 기반
- 내장 AI: 선택적 사용, 미지원 시 자동 fallback
- 지원 방식: 인라인 플래그 활성화 + 키워드 기반 툴 호출

### Google 공식 입장 반영
- 일부 Chrome/AI 기능은 실험 플래그를 통해 활성화해야 합니다.
- 지원 여부는 Chrome 버전, 운영체제, 기기 성능, 모델 다운로드 상태에 따라 달라집니다.
- 따라서 확장 프로그램은 **내장 AI가 없더라도 WebMCP 툴 자체를 직접 호출하는 fallback 로직**을 유지합니다.

## ✨ 기능

| 기능 | 설명 |
|---|---|
| 📡 **WebMCP 툴 조회** | 현재 페이지에서 WebMCP로 등록된 tool(`yonja.*`) 목록을 자동 감지해 표시합니다. |
| 💬 **자연어 질문 → 툴 호출** | Chrome 내장 AI(제미나이 나노)가 질문을 분석해 적절한 WebMCP 툴을 자동 호출합니다. |
| 🔁 **키워드 폴백 라우팅** | 내장 AI가 없으면 키워드 기반으로 `service`/`consultant`/`diagnosis` 툴을 직접 호출합니다. |
| 🏷️ **배지 표시** | 툴바 아이콘에 등록된 툴 개수를 표시합니다. |

등록된 툴:
- `yonja.service.get_info` — 서비스 정보(가격/구성) 조회
- `yonja.consultant.get_info` — 상담사 정보 조회
- `yonja.diagnosis.submit` — 재회 가능성 진단 제출

## 📦 파일 구조

```
webmcp-extension/
├── manifest.json       # 확장 설정 (MV3)
├── background.js       # 서비스 워커 (배지 표시)
├── content.js          # 페이지의 WebMCP API와 통신
├── popup.html          # 팝업 UI
├── popup.js            # 팝업 로직 (내장 AI 연동)
└── icons/              # 아이콘 (16/48/128)
```

## 🚀 설치 방법

1. **로컬 서버 실행** (WebMCP 툴이 노출된 페이지 필요)
   ```bash
   cd /Users/ilyoungkim/Projects/webMCP_luvd
   python3 -m http.server 8000
   ```
   브라우저에서 `http://localhost:8000/yonja.html` 접속.

2. **확장 프로그램 로드**
   - Chrome 주소창에 `chrome://extensions` 입력
   - 우측 상단 **개발자 모드** 켜기
   - **압축해제된 확장 프로그램을 로드합니다** 클릭
   - `webmcp-extension/` 폴더 선택

3. **사용**
   - `yonja.html`이 열린 탭에서 툴바의 💘 아이콘 클릭
   - 팝업에서 툴 상태 확인
   - 질문 입력 후 **AI 분석 실행** 클릭

## 🤖 Chrome 내장 AI 사용

이 확장은 **Chrome 내장 Gemini Nano**(`window.ai.languageModel`)를 우선 사용합니다.

- **지원 확인**: Chrome 131+ 및 `chrome://flags`에서 내장 AI 활성화
  - `chrome://flags/#prompt-api-for-gemini-nano` → **Enabled**
  - `chrome://flags/#optimization-guide-on-device-model` → **Enabled BypassPerfRequirement** (로컬 모델 다운로드)
- 내장 AI가 **없으면 자동으로 키워드 기반 폴백**으로 동작합니다.
- 팝업에서 "Chrome 내장 AI 우선 사용" 체크박스로 토글할 수 있습니다.

> ⚠️ `window.ai`는 아직 실험적 API입니다. Chrome 버전에 따라 팝업의 AI 상태가 "미지원"으로 나올 수 있으며, 그 경우에도 WebMCP 툴 직접 호출은 정상 동작합니다.

## 🔧 동작 방식

```
[팝업 질문]
   │
   ▼
Chrome 내장 AI (window.ai.languageModel)  ──▶ 툴/인자 해석 (JSON)
   │  (없으면)
   ▼
키워드 기반 폴백 라우팅
   │
   ▼
chrome.tabs.sendMessage → content.js → document.modelContext.invoke/execute
   │
   ▼
결과 반환 → 팝업 표시
```
