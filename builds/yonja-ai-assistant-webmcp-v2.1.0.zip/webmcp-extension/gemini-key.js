// ─────────────────────────────────────────────────────────────
// gemini-key.js — Google Gemini API 키 (별도 관리 파일)
// ⚠️ 이 파일은 절대 GitHub 등 공개 저장소에 커밋하지 마세요.
//    .gitignore에 추가해 두는 것을 권장합니다.
// ─────────────────────────────────────────────────────────────
const GEMINI_API_KEY = 'AQ.Ab8RN6IzQWffis17T3BECXs82pEAn748oFuRsZKsKf0qEPU9pQ'; // 새 키를 여기에 입력하세요
